const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { execFileSync } = require('node:child_process');

const root = path.resolve(__dirname, '..');

function buildServiceAreas() {
  execFileSync(process.execPath, ['build.mjs'], { cwd: root, stdio: 'pipe' });
  return fs.readFileSync(path.join(root, 'public', 'service-areas', 'index.html'), 'utf8');
}

test('service-area directory groups City of Adelaide streets and links each one to contact', () => {
  const html = buildServiceAreas();

  assert.match(html, /Adelaide CBD/);
  assert.match(html, /North Adelaide/);
  assert.match(html, /King William Street/);
  assert.match(html, /O'Connell Street/);
  assert.match(html, /href="\/contact\/\?location=King%20William%20Street%2C%20Adelaide%20CBD"/);
});

test('contact page uses a selected street as the project location', () => {
  const source = fs.readFileSync(path.join(root, 'src', 'assets', 'base.js'), 'utf8');

  assert.match(source, /get\('location'\)/);
  assert.match(source, /Project location: \$\{selectedLocation\}/);
});

test('integrity checker expects the service-areas page in the generated site', () => {
  const source = fs.readFileSync(path.join(root, 'check.cjs'), 'utf8');

  assert.match(source, /expect 24/);
  assert.match(source, /htmlFiles\.length === 24/);
});

test('test command serialises builds that share the public output directory', () => {
  const manifest = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));

  assert.equal(manifest.scripts.test, 'node --test --test-concurrency=1 test/*.test.cjs');
});
